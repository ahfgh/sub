<?php

declare(strict_types=1);
require_once __DIR__ . '/config.php';
require_once __DIR__ . '/fetch.php';
require_login();

if (isset($_GET['logout'])) {
    $_SESSION = [];
    session_destroy();
    header('Location: index.php');
    exit;
}

if (isset($_GET['ajax']) && $_GET['ajax'] === 'test_source') {
    header('Content-Type: application/json; charset=utf-8');
    $url = trim((string) ($_GET['url'] ?? ''));

    if (!is_valid_url($url)) {
        echo json_encode(['ok' => false, 'error' => 'لینک معتبر نیست.'], JSON_UNESCAPED_UNICODE);
        exit;
    }

    $remote = fetch_remote_content($url);
    if (!$remote['ok']) {
        echo json_encode($remote, JSON_UNESCAPED_UNICODE | JSON_UNESCAPED_SLASHES);
        exit;
    }

    $parsed = parse_subscription_data($remote['body'], $remote['content_type']);
    echo json_encode($parsed, JSON_UNESCAPED_UNICODE | JSON_UNESCAPED_SLASHES);
    exit;
}

$message = $_SESSION['flash_message'] ?? null;
$error = $_SESSION['flash_error'] ?? null;
$newLink = $_SESSION['flash_created_link'] ?? null;
unset($_SESSION['flash_message'], $_SESSION['flash_error'], $_SESSION['flash_created_link']);

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    if (!verify_csrf($_POST['csrf_token'] ?? null)) {
        $_SESSION['flash_error'] = 'درخواست نامعتبر است.';
        header('Location: panel.php');
        exit;
    }

    $action = (string) ($_POST['action'] ?? '');

    if ($action === 'create') {
        $name = trim((string) ($_POST['name'] ?? ''));
        $sourceUrl = trim((string) ($_POST['source_url'] ?? ''));

        if ($name === '') {
            $_SESSION['flash_error'] = 'ID مشتری را وارد کنید.';
        } elseif (!is_valid_url($sourceUrl)) {
            $_SESSION['flash_error'] = 'لینک ساب اصلی معتبر نیست.';
        } else {
            $item = upsert_item($name, $sourceUrl);
            $_SESSION['flash_message'] = 'لینک جدید ساخته شد.';
            $_SESSION['flash_created_link'] = app_sub_url($item['token']);
        }

        header('Location: panel.php');
        exit;
    }

    if ($action === 'delete') {
        $id = (string) ($_POST['id'] ?? '');
        $_SESSION['flash_message'] = delete_item($id) ? 'آیتم حذف شد.' : 'آیتم پیدا نشد.';
        header('Location: panel.php');
        exit;
    }

    if ($action === 'bulk_delete') {
        $ids = $_POST['ids'] ?? [];
        if (!is_array($ids) || !$ids) {
            $_SESSION['flash_error'] = 'هیچ موردی انتخاب نشده است.';
        } else {
            $deleted = 0;
            foreach ($ids as $id) {
                if (delete_item((string) $id)) {
                    $deleted++;
                }
            }
            $_SESSION['flash_message'] = $deleted > 0 ? ('تعداد ' . $deleted . ' آیتم حذف شد.') : 'موردی حذف نشد.';
        }
        header('Location: panel.php');
        exit;
    }
}

$data = load_data();
$items = array_reverse($data['items']);
$totalCount = count($items);
?>
<!doctype html>
<html lang="fa" dir="rtl">
<head>
    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <title>پنل مدیریت</title>
    <link rel="preconnect" href="https://fonts.googleapis.com">
    <link href="https://fonts.googleapis.com/css2?family=Vazirmatn:wght@400;500;700;800&display=swap" rel="stylesheet">
    <style>
        :root{
            --bg-1:#020617;--bg-2:#07122c;--panel:rgba(11,25,54,.88);--panel-2:rgba(14,30,63,.88);
            --border:rgba(114,148,199,.20);--muted:#8ea4c8;--text:#eef4ff;--accent:#3b82f6;--danger:#dc2626;
            --shadow:0 18px 60px rgba(0,0,0,.32);--ok:#16a34a;--warn:#f59e0b;--bad:#ef4444;
        }
        *{box-sizing:border-box}
        body{
            margin:0;color:var(--text);font-family:'Vazirmatn',Tahoma,Arial,sans-serif;
            background:radial-gradient(circle at top right, rgba(59,130,246,.14), transparent 28%),
            radial-gradient(circle at left bottom, rgba(96,165,250,.08), transparent 28%),
            linear-gradient(180deg,var(--bg-1),var(--bg-2));
        }
        .wrap{max-width:1320px;margin:0 auto;padding:24px 18px 40px}
        .top{display:flex;justify-content:space-between;align-items:center;gap:16px;flex-wrap:wrap;margin-bottom:18px}
        .brand{display:flex;align-items:center;gap:16px}
        .brand img{width:72px;height:72px;object-fit:contain}
        .sub{color:var(--muted)}
        .card{
            background:linear-gradient(180deg,var(--panel),var(--panel-2));
            border:1px solid var(--border);border-radius:24px;padding:22px;box-shadow:var(--shadow);margin-top:18px;
        }
        .stats{display:grid;grid-template-columns:repeat(4,minmax(160px,1fr));gap:14px}
        .stat{
            background:rgba(6,17,37,.75);border:1px solid var(--border);border-radius:20px;padding:16px 18px;
        }
        .stat .label{color:#9bb2d7;font-size:13px;margin-bottom:6px}
        .stat .value{font-size:28px;font-weight:800}
        .grid{display:grid;grid-template-columns:220px 1fr auto auto;gap:12px;align-items:center}
        .input{
            width:100%;padding:13px 14px;border-radius:14px;border:1px solid rgba(114,148,199,.26);
            background:#061125;color:#fff;font-family:inherit
        }
        .btn{
            border:0;border-radius:14px;background:linear-gradient(135deg,var(--accent),#2563eb);color:#fff;
            padding:13px 16px;font-family:inherit;font-size:14px;font-weight:700;cursor:pointer;
            text-decoration:none;display:inline-flex;align-items:center;justify-content:center;gap:8px;white-space:nowrap
        }
        .btn-alt{background:#12213d;border:1px solid var(--border)}
        .btn-danger{background:linear-gradient(135deg,#dc2626,#b91c1c)}
        .btn-ghost{background:#12213d;border:1px solid var(--border)}
        .btn-sm{padding:9px 12px;border-radius:12px;font-size:13px}
        .toolbar{display:flex;justify-content:space-between;align-items:center;gap:12px;flex-wrap:wrap}
        .toolbar-right,.toolbar-left{display:flex;align-items:center;gap:10px;flex-wrap:wrap}
        .search{max-width:320px}
        .msg,.err{
            padding:13px 14px;border-radius:16px;margin-top:14px;font-weight:500
        }
        .msg{background:rgba(22,163,74,.16);color:#c7f9d4;border:1px solid rgba(34,197,94,.18)}
        .err{background:rgba(127,29,29,.28);color:#fecaca;border:1px solid rgba(248,113,113,.18)}
        .test-box{margin-top:14px;display:none}
        .table-wrap{overflow:auto;margin-top:14px}
        table{width:100%;border-collapse:collapse;min-width:900px}
        th,td{padding:14px 12px;border-bottom:1px solid rgba(114,148,199,.14);text-align:right;vertical-align:middle}
        th{color:#aac0e8;font-size:13px;font-weight:700}
        td{font-size:14px}
        .actions{display:flex;gap:8px;flex-wrap:wrap}
        .pill{
            display:inline-flex;align-items:center;justify-content:center;padding:6px 10px;border-radius:999px;
            font-size:12px;font-weight:700;border:1px solid rgba(114,148,199,.24);background:#10203d;color:#dbeafe
        }
        .pill.ok{background:rgba(22,163,74,.16);color:#d1fae5;border-color:rgba(34,197,94,.2)}
        .pill.warn{background:rgba(245,158,11,.16);color:#fde68a;border-color:rgba(245,158,11,.24)}
        .pill.bad{background:rgba(127,29,29,.28);color:#fecaca;border-color:rgba(248,113,113,.18)}
        .checkbox{width:18px;height:18px;accent-color:#3b82f6}
        .count-box{color:#9bb2d7;font-size:13px}
        .hidden{display:none!important}
        @media (max-width:1080px){
            .stats{grid-template-columns:repeat(2,minmax(160px,1fr))}
            .grid{grid-template-columns:1fr}
            .search{max-width:none;width:100%}
        }
        @media (max-width:640px){
            .stats{grid-template-columns:1fr}
        }
    </style>
</head>
<body>
<div class="wrap">
    <div class="top">
        <div class="brand">
            <img src="<?= e(LOGO_URL) ?>" alt="North Logo" onerror="this.style.display='none'">
            <div>
                <h1 style="margin:0 0 6px;font-size:34px;font-weight:800">پنل مدیریت</h1>
                <div class="sub">مدیریت سریع کاربران، جستجو، انتخاب گروهی و آمار کلی</div>
            </div>
        </div>
        <a class="btn btn-ghost" href="?logout=1">خروج</a>
    </div>

    <div class="stats">
        <div class="stat"><div class="label">تعداد کل اکانت‌ها</div><div class="value" id="stat-total"><?= e((string)$totalCount) ?></div></div>
        <div class="stat"><div class="label">حجم کم (زیر 200MB)</div><div class="value" id="stat-low">0</div></div>
        <div class="stat"><div class="label">نزدیک انقضا</div><div class="value" id="stat-expiring">0</div></div>
        <div class="stat"><div class="label">انتخاب‌شده‌ها</div><div class="value" id="stat-selected">0</div></div>
    </div>

    <div class="card">
        <h2 style="margin:0 0 14px">ساخت لینک جدید</h2>
        <?php if ($message): ?><div class="msg"><?= e($message) ?></div><?php endif; ?>
        <?php if ($error): ?><div class="err"><?= e($error) ?></div><?php endif; ?>

        <?php if (!empty($newLink)): ?>
            <div class="msg" id="newLinkBox" data-new-link="<?= e($newLink) ?>">
                لینک جدید ساخته شد.
                <button type="button" class="btn btn-sm" id="copyNewLinkBtn" style="margin-right:10px">کپی لینک مشتری</button>
                <span id="copyNewLinkMsg" style="margin-right:8px"></span>
            </div>
        <?php endif; ?>

        <form method="post">
            <input type="hidden" name="csrf_token" value="<?= e(csrf_token()) ?>">
            <input type="hidden" name="action" value="create">
            <div class="grid">
                <input class="input" name="name" id="nameInput" placeholder="ID مشتری" required>
                <input class="input" name="source_url" id="sourceUrlInput" placeholder="لینک ساب اصلی" required>
                <button class="btn btn-alt" type="button" id="testBtn">تست لینک منبع</button>
                <button class="btn" type="submit">ساخت لینک</button>
            </div>
        </form>
        <div id="testBox" class="test-box"></div>
    </div>

    <div class="card">
        <div class="toolbar">
            <div class="toolbar-right">
                <h2 style="margin:0">لیست کاربران</h2>
                <span class="count-box">نمایش <span id="visibleCount"><?= e((string)$totalCount) ?></span> مورد</span>
            </div>
            <div class="toolbar-left">
                <input class="input search" id="searchInput" placeholder="جستجو بر اساس ID مشتری یا نام کانفیگ">
                <button type="button" class="btn btn-alt btn-sm" id="selectAllBtn">انتخاب همه</button>
                <button type="button" class="btn btn-alt btn-sm" id="clearSelectionBtn">لغو انتخاب</button>
                <button type="button" class="btn btn-danger btn-sm" id="bulkDeleteBtn">حذف انتخاب‌شده‌ها</button>
            </div>
        </div>

        <form method="post" id="bulkDeleteForm">
            <input type="hidden" name="csrf_token" value="<?= e(csrf_token()) ?>">
            <input type="hidden" name="action" value="bulk_delete">

            <div class="table-wrap">
                <table>
                    <thead>
                    <tr>
                        <th style="width:52px"><input type="checkbox" class="checkbox" id="masterCheckbox"></th>
                        <th style="width:70px">ردیف</th>
                        <th>ID مشتری</th>
                        <th>نام کانفیگ</th>
                        <th>حجم باقی‌مانده</th>
                        <th>عملیات</th>
                    </tr>
                    </thead>
                    <tbody id="itemsTable">
                    <?php if (!$items): ?>
                        <tr><td colspan="6">هنوز موردی ثبت نشده است.</td></tr>
                    <?php endif; ?>
                    <?php foreach ($items as $index => $item): ?>
                        <tr data-row data-name="<?= e($item['name'] ?? '') ?>">
                            <td>
                                <input type="checkbox" class="checkbox row-checkbox" name="ids[]" value="<?= e($item['id']) ?>">
                            </td>
                            <td><?= e((string)($index + 1)) ?></td>
                            <td><?= e($item['name'] ?? '') ?></td>
                            <td>
                                <span class="pill" data-config-name>در حال بررسی...</span>
                            </td>
                            <td>
                                <span class="pill" data-remaining>در حال بررسی...</span>
                                <span class="hidden" data-remaining-raw></span>
                                <span class="hidden" data-expiry-raw></span>
                            </td>
                            <td>
                                <div class="actions">
                                    <a class="btn btn-alt btn-sm" href="<?= e(app_sub_url($item['token'])) ?>" target="_blank">مشاهده</a>
                                    <form method="post" style="display:inline-block" onsubmit="return confirm('حذف شود؟');">
                                        <input type="hidden" name="csrf_token" value="<?= e(csrf_token()) ?>">
                                        <input type="hidden" name="action" value="delete">
                                        <input type="hidden" name="id" value="<?= e($item['id']) ?>">
                                        <button type="submit" class="btn btn-danger btn-sm">حذف</button>
                                    </form>
                                </div>
                            </td>
                            <td class="hidden" data-token><?= e($item['token']) ?></td>
                        </tr>
                    <?php endforeach; ?>
                    </tbody>
                </table>
            </div>
        </form>
    </div>
</div>

<script>
async function copyText(text) {
    if (navigator.clipboard && window.isSecureContext) {
        await navigator.clipboard.writeText(text);
        return;
    }
    const ta = document.createElement('textarea');
    ta.value = text;
    ta.style.position = 'fixed';
    ta.style.top = '-9999px';
    document.body.appendChild(ta);
    ta.focus();
    ta.select();
    document.execCommand('copy');
    document.body.removeChild(ta);
}

function normalizeConfigName(name) {
    const raw = (name || '').trim();
    if (!raw) return 'پیدا نشد';
    const m = raw.match(/\b(VIP\d{1,6})\b/i);
    if (m) return m[1].toUpperCase();
    return raw.replace(/\s*-\s*North_VPN\s*$/i, '').trim();
}

function parseRemainingToMB(value) {
    if (!value) return null;
    const text = String(value).trim().toUpperCase();
    const m = text.match(/([\d.]+)\s*(KB|MB|GB|B)/);
    if (!m) return null;
    const num = parseFloat(m[1]);
    const unit = m[2];
    if (Number.isNaN(num)) return null;
    if (unit === 'GB') return num * 1024;
    if (unit === 'MB') return num;
    if (unit === 'KB') return num / 1024;
    if (unit === 'B') return num / (1024 * 1024);
    return null;
}

function parseExpiryDays(value) {
    if (!value) return null;
    const text = String(value).trim();
    const m = text.match(/(\d{4})\/(\d{1,2})\/(\d{1,2})/);
    if (!m) return null;
    return 999; // برای نسخه فعلی با تاریخ شمسی واقعی محاسبه نمی‌کنیم؛ فقط وقتی از API قابل‌محاسبه شد اضافه می‌شود
}

function updateSelectedCount() {
    const selected = document.querySelectorAll('.row-checkbox:checked').length;
    document.getElementById('stat-selected').textContent = String(selected);
}

function updateVisibleCount() {
    const visible = [...document.querySelectorAll('#itemsTable tr[data-row]')].filter(row => row.style.display !== 'none').length;
    document.getElementById('visibleCount').textContent = String(visible);
}

function updateStats() {
    const rows = [...document.querySelectorAll('#itemsTable tr[data-row]')];
    let low = 0;
    let expiring = 0;

    rows.forEach(row => {
        if (row.style.display === 'none') return;
        const remainingRaw = row.querySelector('[data-remaining-raw]').textContent.trim();
        const expiryRaw = row.querySelector('[data-expiry-raw]').textContent.trim();

        const remainingMb = parseRemainingToMB(remainingRaw);
        if (remainingMb !== null && remainingMb < 200) low++;

        const expiryDays = parseExpiryDays(expiryRaw);
        if (expiryDays !== null && expiryDays <= 3) expiring++;
    });

    document.getElementById('stat-low').textContent = String(low);
    document.getElementById('stat-expiring').textContent = String(expiring);
}

function setRemainingBadge(el, value) {
    const mb = parseRemainingToMB(value);
    el.textContent = value || '-';
    el.className = 'pill';
    if (mb === null) return;
    if (mb < 200) el.classList.add('warn');
    else el.classList.add('ok');
}

async function loadRowInfo(row) {
    const token = row.querySelector('[data-token]').textContent.trim();
    if (!token) return;
    const configEl = row.querySelector('[data-config-name]');
    const remainingEl = row.querySelector('[data-remaining]');
    try {
        const res = await fetch('fetch.php?token=' + encodeURIComponent(token), {headers:{'X-Requested-With':'XMLHttpRequest'}});
        const data = await res.json();

        if (!data.ok) {
            configEl.textContent = 'خطا';
            configEl.className = 'pill bad';
            remainingEl.textContent = '-';
            remainingEl.className = 'pill bad';
            return;
        }

        const info = data.data || {};
        const configName = normalizeConfigName(info.config_name || '');
        configEl.textContent = configName;
        configEl.className = 'pill' + (info.config_error ? ' bad' : '');

        const remaining = info.remaining || '-';
        setRemainingBadge(remainingEl, remaining);

        row.querySelector('[data-remaining-raw]').textContent = remaining;
        row.querySelector('[data-expiry-raw]').textContent = info.expiry || '';
        row.dataset.config = configName;
        row.dataset.remaining = remaining;
        updateStats();
    } catch (e) {
        configEl.textContent = 'خطا';
        configEl.className = 'pill bad';
        remainingEl.textContent = '-';
        remainingEl.className = 'pill bad';
    }
}

const searchInput = document.getElementById('searchInput');
searchInput.addEventListener('input', function () {
    const q = this.value.trim().toLowerCase();
    document.querySelectorAll('#itemsTable tr[data-row]').forEach(row => {
        const name = (row.dataset.name || '').toLowerCase();
        const config = (row.dataset.config || '').toLowerCase();
        row.style.display = (!q || name.includes(q) || config.includes(q)) ? '' : 'none';
    });
    updateVisibleCount();
    updateStats();
});

document.getElementById('testBtn').addEventListener('click', async () => {
    const url = document.getElementById('sourceUrlInput').value.trim();
    const box = document.getElementById('testBox');
    box.style.display = 'block';
    if (!url) { box.className = 'test-box err'; box.textContent = 'اول لینک منبع را وارد کن.'; return; }
    box.className = 'test-box msg'; box.textContent = 'در حال تست منبع...';
    try {
        const res = await fetch('?ajax=test_source&url=' + encodeURIComponent(url), {headers:{'X-Requested-With':'XMLHttpRequest'}});
        const data = await res.json();
        if (!data.ok) { box.className = 'test-box err'; box.textContent = data.error || 'تست منبع ناموفق بود.'; return; }
        const info = data.data || {};
        let html = 'تست موفق بود';
        if (info.config_name) html += ' | کانفیگ: ' + normalizeConfigName(info.config_name);
        if (info.remaining) html += ' | باقی‌مانده: ' + info.remaining;
        if (info.config_error) html += ' | هشدار: ' + info.config_error;
        box.className = 'test-box msg'; box.textContent = html;
    } catch (e) {
        box.className = 'test-box err'; box.textContent = 'خطا در تست منبع.';
    }
});

document.querySelectorAll('.row-checkbox').forEach(cb => cb.addEventListener('change', updateSelectedCount));
document.getElementById('masterCheckbox').addEventListener('change', function () {
    const checked = this.checked;
    document.querySelectorAll('.row-checkbox').forEach(cb => { if (cb.closest('tr').style.display !== 'none') cb.checked = checked; });
    updateSelectedCount();
});
document.getElementById('selectAllBtn').addEventListener('click', () => {
    document.querySelectorAll('.row-checkbox').forEach(cb => { if (cb.closest('tr').style.display !== 'none') cb.checked = true; });
    document.getElementById('masterCheckbox').checked = true;
    updateSelectedCount();
});
document.getElementById('clearSelectionBtn').addEventListener('click', () => {
    document.querySelectorAll('.row-checkbox').forEach(cb => cb.checked = false);
    document.getElementById('masterCheckbox').checked = false;
    updateSelectedCount();
});
document.getElementById('bulkDeleteBtn').addEventListener('click', () => {
    const selected = document.querySelectorAll('.row-checkbox:checked').length;
    if (!selected) { alert('هیچ موردی انتخاب نشده است.'); return; }
    if (confirm('تعداد ' + selected + ' مورد حذف شود؟')) {
        document.getElementById('bulkDeleteForm').submit();
    }
});

const copyNewLinkBtn = document.getElementById('copyNewLinkBtn');
if (copyNewLinkBtn) {
    copyNewLinkBtn.addEventListener('click', async () => {
        const box = document.getElementById('newLinkBox');
        const msg = document.getElementById('copyNewLinkMsg');
        try {
            await copyText(box.dataset.newLink || '');
            msg.textContent = 'کپی شد';
        } catch (e) {
            msg.textContent = 'کپی نشد';
        }
        setTimeout(() => { msg.textContent = ''; }, 1600);
    });
}

document.querySelectorAll('#itemsTable tr[data-row]').forEach(loadRowInfo);
updateVisibleCount();
updateSelectedCount();
updateStats();
</script>
</body>
</html>
