<?php

declare(strict_types=1);
require_once __DIR__ . '/config.php';

$token = '';

if (isset($_GET['token'])) {
    $token = trim((string) $_GET['token']);
} elseif (isset($_SERVER['REQUEST_URI'])) {
    $path = parse_url((string) $_SERVER['REQUEST_URI'], PHP_URL_PATH);
    if (preg_match('#/sub/([a-f0-9]{16,128})$#i', (string) $path, $m)) {
        $token = $m[1];
    }
}

$item = $token !== '' ? find_item_by_token($token) : null;

if (!$item) {
    http_response_code(404);
}
?>
<!doctype html>
<html lang="fa" dir="rtl">
<head>
    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <title><?= $item ? e($item['name']) : 'لینک نامعتبر' ?></title>
    <link rel="preconnect" href="https://fonts.googleapis.com">
    <link href="https://fonts.googleapis.com/css2?family=Vazirmatn:wght@400;500;700;800&display=swap" rel="stylesheet">
    <style>
        :root{
            --bg-1:#020617;
            --bg-2:#07122c;
            --panel:rgba(11,25,54,.88);
            --panel-2:rgba(14,30,63,.88);
            --border:rgba(114,148,199,.22);
            --muted:#8ea4c8;
            --text:#eef4ff;
            --accent:#3b82f6;
            --success:#22c55e;
            --shadow:0 18px 60px rgba(0,0,0,.32);
        }
        *{box-sizing:border-box}
        body{
            margin:0;
            min-height:100vh;
            color:var(--text);
            font-family:'Vazirmatn',Tahoma,Arial,sans-serif;
            background:
                radial-gradient(circle at top right, rgba(59,130,246,.14), transparent 28%),
                radial-gradient(circle at left bottom, rgba(96,165,250,.08), transparent 28%),
                linear-gradient(180deg,var(--bg-1),var(--bg-2));
        }
        .wrap{max-width:1180px;margin:0 auto;padding:28px 20px 44px}
        .hero{display:grid;grid-template-columns:180px 1fr;gap:22px;align-items:center;margin-bottom:26px}
        .logo-box{min-height:124px;display:flex;align-items:center;justify-content:flex-start}
        .logo-box img{max-width:160px;max-height:120px;width:auto;height:auto;object-fit:contain;filter:drop-shadow(0 14px 28px rgba(0,0,0,.2))}
        .hero-main{display:flex;flex-direction:column;align-items:flex-end;gap:12px}
        .hero h1{margin:0;font-size:54px;line-height:1;font-weight:800;letter-spacing:-1px}
        .status-bar{display:inline-flex;align-items:center;gap:10px;padding:12px 18px;background:rgba(20,34,68,.82);border:1px solid var(--border);border-radius:999px;box-shadow:var(--shadow);font-size:16px;font-weight:700}
        .status-dot{width:10px;height:10px;border-radius:50%;background:var(--success);box-shadow:0 0 0 6px rgba(34,197,94,.12);display:inline-block}
        .status-dot.off{background:#ef4444;box-shadow:0 0 0 6px rgba(239,68,68,.12)}
        .cards-main{display:grid;grid-template-columns:repeat(3,minmax(0,1fr));gap:18px;margin-bottom:18px}
        .cards-secondary{display:grid;grid-template-columns:minmax(0,1fr);gap:18px;margin-bottom:18px;max-width:calc((100% - 36px)/3)}
        .card{background:linear-gradient(180deg,var(--panel),var(--panel-2));border:1px solid var(--border);border-radius:24px;padding:22px 24px;box-shadow:var(--shadow);min-height:126px;display:flex;flex-direction:column;justify-content:center}
        .label{color:var(--muted);font-size:14px;margin-bottom:12px;font-weight:500}
        .value{font-size:20px;line-height:1.55;font-weight:800;letter-spacing:-.3px;word-break:break-word}
        .config-box{background:linear-gradient(180deg,var(--panel),var(--panel-2));border:1px solid var(--border);border-radius:28px;padding:24px;box-shadow:var(--shadow)}
        .config-head{display:flex;align-items:center;justify-content:space-between;gap:14px;margin-bottom:18px;flex-wrap:wrap}
        .config-title{font-size:34px;font-weight:800;line-height:1}
        .config-name{display:inline-flex;align-items:center;justify-content:center;background:rgba(79,70,229,.22);color:#e8ecff;border:1px solid rgba(129,140,248,.45);padding:8px 14px;border-radius:999px;font-size:15px;font-weight:700}
        .config-link{direction:ltr;text-align:left;font-family:'Vazirmatn',Tahoma,Arial,sans-serif;background:#071226;border:1px solid rgba(114,148,199,.24);border-radius:20px;padding:18px;line-height:2;color:#d8e4ff;word-break:break-all;min-height:96px;font-size:15px;font-weight:500}
        .config-actions{display:flex;align-items:center;justify-content:flex-end;gap:10px;margin-top:16px;flex-wrap:wrap}
        .copy-btn{border:0;border-radius:16px;background:linear-gradient(135deg,var(--accent),#2563eb);color:#fff;padding:13px 20px;font-size:15px;font-weight:700;cursor:pointer;box-shadow:0 12px 28px rgba(37,99,235,.28);font-family:'Vazirmatn',Tahoma,Arial,sans-serif}
        .copy-msg{font-size:14px;color:#b7caf0;min-width:58px;text-align:left;font-family:'Vazirmatn',Tahoma,Arial,sans-serif}
        .err{margin-top:18px;background:rgba(127,29,29,.28);color:#fecaca;padding:14px 16px;border-radius:18px;border:1px solid rgba(248,113,113,.2)}
        .support-box{display:none;margin-top:18px;background:linear-gradient(180deg,rgba(245,158,11,.16),rgba(245,158,11,.08));border:1px solid rgba(245,158,11,.26);border-radius:24px;padding:22px;box-shadow:var(--shadow)}
        .support-title{font-size:24px;font-weight:800;margin-bottom:10px;color:#fde68a}
        .support-text{font-size:15px;line-height:2;color:#fff3c4;margin-bottom:14px}
        .support-actions{display:flex;gap:10px;flex-wrap:wrap}
        .support-btn{display:inline-flex;align-items:center;justify-content:center;padding:12px 16px;border-radius:16px;text-decoration:none;font-size:14px;font-weight:700;color:#fff;background:linear-gradient(135deg,#2563eb,#1d4ed8)}
        .support-btn.alt{background:#0f1b35;border:1px solid rgba(245,158,11,.26);color:#fde68a}
        @media (max-width:980px){.hero{grid-template-columns:1fr;justify-items:center;text-align:center}.hero-main{align-items:center}.cards-main{grid-template-columns:repeat(2,minmax(0,1fr))}.cards-secondary{max-width:none}}
        @media (max-width:640px){.wrap{padding:18px 14px 34px}.hero h1{font-size:38px}.cards-main{grid-template-columns:1fr}.status-bar{font-size:14px;padding:11px 14px}.config-title{font-size:26px}.card{min-height:112px;padding:18px}.value{font-size:18px}}
    </style>
</head>
<body>
<div class="wrap">
    <?php if (!$item): ?>
        <div class="err">لینک نامعتبر یا حذف شده است.</div>
    <?php else: ?>
        <div class="hero">
            <div class="logo-box">
                <img src="<?= e(LOGO_URL) ?>" alt="North Logo" onerror="this.style.display='none'">
            </div>
            <div class="hero-main">
                <h1><?= e($item['name']) ?></h1>
                <div id="statusBar" class="status-bar">
                    <span class="status-dot" id="statusDot"></span>
                    <span id="statusText">در حال دریافت اطلاعات...</span>
                </div>
            </div>
        </div>

        <div class="cards-main">
            <div class="card"><div class="label">دانلود</div><div class="value" id="v-download">---</div></div>
            <div class="card"><div class="label">آپلود</div><div class="value" id="v-upload">---</div></div>
            <div class="card"><div class="label">مصرف</div><div class="value" id="v-usage">---</div></div>
            <div class="card"><div class="label">حجم کل</div><div class="value" id="v-total">---</div></div>
            <div class="card"><div class="label">باقی‌مانده</div><div class="value" id="v-remaining">---</div></div>
            <div class="card"><div class="label">تاریخ انقضا</div><div class="value" id="v-expiry">---</div></div>
        </div>

        <div class="cards-secondary">
            <div class="card"><div class="label">آخرین اتصال</div><div class="value" id="v-last_connection">---</div></div>
        </div>

        <div class="config-box" id="configBox" style="display:none;">
            <div class="config-head">
                <div class="config-title">کانفیگ</div>
                <div class="config-name" id="configName">---</div>
            </div>
            <div class="config-link" id="configLink">---</div>
            <div class="config-actions">
                <span class="copy-msg" id="copyMsg"></span>
                <button type="button" class="copy-btn" id="copyBtn">کپی کانفیگ</button>
            </div>
        </div>

        <div class="support-box" id="supportBox">
            <div class="support-title">حجم شما به پایان رسیده است</div>
            <div class="support-text" id="supportText">---</div>
            <div class="support-actions">
                <a class="support-btn" id="supportTelegramBtn" href="#" target="_blank" rel="noopener">پیام در تلگرام</a>
                <a class="support-btn alt" id="supportChatBtn" href="#" target="_blank" rel="noopener">پیام از طریق لینک پشتیبانی</a>
            </div>
        </div>

        <div id="errorBox" class="err" style="display:none;"></div>
    <?php endif; ?>
</div>
<?php if ($item): ?>
<script>
const fetchUrl = <?= json_encode(rtrim(base_url(), '/') . '/fetch.php?token=' . rawurlencode($token), JSON_UNESCAPED_UNICODE | JSON_UNESCAPED_SLASHES) ?>;
const fields = ['download','upload','usage','total','remaining'];

function setText(id, value) {
    const el = document.getElementById(id);
    if (!el) return;
    el.textContent = value && String(value).trim() !== '' ? value : 'نامشخص';
}

function formatPersianDate(value) {
    if (!value || String(value).trim() === '') return 'نامشخص';
    const normalized = String(value).trim().replace(' UTC', 'Z').replace(' ', 'T');
    const date = new Date(normalized);
    if (Number.isNaN(date.getTime())) return value;

    const formatter = new Intl.DateTimeFormat('fa-IR-u-ca-persian', {
        year: 'numeric', month: '2-digit', day: '2-digit',
        hour: '2-digit', minute: '2-digit', hour12: false
    });

    const parts = formatter.formatToParts(date);
    const map = {};
    parts.forEach(p => { if (p.type !== 'literal') map[p.type] = p.value; });
    return `${map.year}/${map.month}/${map.day} - ${map.hour}:${map.minute}`;
}

fetch(fetchUrl, {headers:{'X-Requested-With':'XMLHttpRequest'}})
    .then(r => r.json())
    .then(data => {
        const statusText = document.getElementById('statusText');
        const dot = document.getElementById('statusDot');

        if (!data.ok) {
            dot.classList.add('off');
            statusText.textContent = 'خطا در دریافت اطلاعات';
            const box = document.getElementById('errorBox');
            box.style.display = 'block';
            box.textContent = data.error || 'خطای نامشخص';
            return;
        }

        const info = data.data || {};
        fields.forEach(key => setText('v-' + key, info[key] || null));
        setText('v-expiry', formatPersianDate(info.expiry || null));
        setText('v-last_connection', formatPersianDate(info.last_connection || null));
        statusText.textContent = 'اطلاعات با موفقیت بروزرسانی شد';

        if (info.subscription_link) {
            document.getElementById('configBox').style.display = 'block';
            setText('configName', info.config_name || null);
            document.getElementById('configLink').textContent = info.subscription_link;
        }

        if (info.is_exhausted) {
            const supportBox = document.getElementById('supportBox');
            const supportText = document.getElementById('supportText');
            const tgBtn = document.getElementById('supportTelegramBtn');
            const chatBtn = document.getElementById('supportChatBtn');
            supportBox.style.display = 'block';
            supportText.textContent = info.support_message || 'اگر دسترسی شما قطع شده، از طریق یکی از راه‌های زیر پیام بدهید. لطفاً در پیام خودتان هیچ اشاره‌ای به VPN نکنید و فقط مشکل دسترسی یا تمدید را اعلام کنید.';
            tgBtn.href = info.support_telegram_url || '#';
            chatBtn.href = info.support_chat_url || '#';
        }

        if (info.config_error) {
            const box = document.getElementById('errorBox');
            box.style.display = 'block';
            box.textContent = info.config_error;
        }
    })
    .catch(() => {
        const statusText = document.getElementById('statusText');
        const dot = document.getElementById('statusDot');
        dot.classList.add('off');
        statusText.textContent = 'خطا در ارتباط با سرور';
    });

async function copyTextWithFallback(text) {
    if (navigator.clipboard && window.isSecureContext) {
        await navigator.clipboard.writeText(text);
        return true;
    }

    const ta = document.createElement('textarea');
    ta.value = text;
    ta.setAttribute('readonly', 'readonly');
    ta.style.position = 'fixed';
    ta.style.top = '-9999px';
    ta.style.left = '-9999px';
    document.body.appendChild(ta);
    ta.focus();
    ta.select();
    ta.setSelectionRange(0, ta.value.length);

    let ok = false;
    try {
        ok = document.execCommand('copy');
    } finally {
        document.body.removeChild(ta);
    }

    if (!ok) throw new Error('copy-failed');
    return true;
}

const copyBtn = document.getElementById('copyBtn');
if (copyBtn) {
    copyBtn.addEventListener('click', async () => {
        const text = document.getElementById('configLink').textContent || '';
        const msg = document.getElementById('copyMsg');
        if (!text || text === '---') return;

        try {
            await copyTextWithFallback(text);
            msg.textContent = 'کپی شد';
        } catch (e) {
            msg.textContent = 'کپی نشد';
        }
        setTimeout(() => { msg.textContent = ''; }, 2200);
    });
}
</script>
<?php endif; ?>
</body>
</html>
