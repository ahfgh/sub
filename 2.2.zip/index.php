<?php

declare(strict_types=1);
require_once __DIR__ . '/config.php';

if (!empty($_SESSION['logged_in'])) {
    header('Location: panel.php');
    exit;
}

$error = null;

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    if (!verify_csrf($_POST['csrf_token'] ?? null)) {
        $error = 'درخواست نامعتبر است. دوباره تلاش کنید.';
    } else {
        $username = trim((string) ($_POST['username'] ?? ''));
        $password = (string) ($_POST['password'] ?? '');

        if (hash_equals(ADMIN_USERNAME, $username) && hash_equals(ADMIN_PASSWORD, $password)) {
            $_SESSION['logged_in'] = true;
            session_regenerate_id(true);
            header('Location: panel.php');
            exit;
        }

        $error = 'نام کاربری یا رمز عبور اشتباه است.';
    }
}
?>
<!doctype html>
<html lang="fa" dir="rtl">
<head>
    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <title>ورود به پنل</title>
    <link rel="preconnect" href="https://fonts.googleapis.com">
    <link href="https://fonts.googleapis.com/css2?family=Vazirmatn:wght@400;500;700;800&display=swap" rel="stylesheet">
    <style>
        :root{--bg-1:#020617;--bg-2:#07122c;--panel:rgba(11,25,54,.88);--panel-2:rgba(14,30,63,.88);--border:rgba(114,148,199,.22);--muted:#8ea4c8;--text:#eef4ff;--accent:#3b82f6;--shadow:0 18px 60px rgba(0,0,0,.32)}
        *{box-sizing:border-box}
        body{margin:0;min-height:100vh;color:var(--text);font-family:'Vazirmatn',Tahoma,Arial,sans-serif;background:radial-gradient(circle at top right, rgba(59,130,246,.14), transparent 28%),radial-gradient(circle at left bottom, rgba(96,165,250,.08), transparent 28%),linear-gradient(180deg,var(--bg-1),var(--bg-2));display:flex;align-items:center;justify-content:center;padding:18px}
        .card{width:min(460px,95vw);background:linear-gradient(180deg,var(--panel),var(--panel-2));border:1px solid var(--border);border-radius:26px;padding:28px;box-shadow:var(--shadow)}
        .brand{display:flex;align-items:center;gap:14px;margin-bottom:18px}.brand img{width:68px;height:68px;object-fit:contain}
        h1{margin:0 0 6px;font-size:30px;font-weight:800}.muted{color:var(--muted);margin:0 0 20px}
        label{display:block;margin:12px 0 8px}.input{width:100%;padding:13px 14px;border-radius:14px;border:1px solid rgba(114,148,199,.26);background:#061125;color:#fff;font-family:inherit}
        .btn{width:100%;padding:13px 14px;border:none;border-radius:14px;background:linear-gradient(135deg,var(--accent),#2563eb);color:#fff;font-family:inherit;font-size:15px;font-weight:700;cursor:pointer;margin-top:18px}
        .err{background:rgba(127,29,29,.28);color:#fecaca;padding:12px 14px;border-radius:16px;margin-bottom:14px;border:1px solid rgba(248,113,113,.18)}
    </style>
</head>
<body>
<div class="card">
    <div class="brand">
        <img src="<?= e(LOGO_URL) ?>" alt="North Logo" onerror="this.style.display='none'">
        <div>
            <h1>ورود به پنل</h1>
            <p class="muted">برای مدیریت اکانت‌ها و لینک‌های مشتری وارد شوید.</p>
        </div>
    </div>

    <?php if ($error): ?>
        <div class="err"><?= e($error) ?></div>
    <?php endif; ?>

    <form method="post">
        <input type="hidden" name="csrf_token" value="<?= e(csrf_token()) ?>">
        <label for="username">نام کاربری</label>
        <input class="input" id="username" name="username" required>

        <label for="password">رمز عبور</label>
        <input class="input" id="password" name="password" type="password" required>

        <button class="btn" type="submit">ورود</button>
    </form>
</div>
</body>
</html>
